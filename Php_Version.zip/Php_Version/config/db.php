<?php
declare(strict_types=1);

date_default_timezone_set('UTC');
$env = is_file(__DIR__ . '/../.env') ? parse_ini_file(__DIR__ . '/../.env', false, INI_SCANNER_RAW) : [];
$host = $env['MYSQL_HOST'] ?? 'localhost';
$database = $env['MYSQL_DATABASE'] ?? '4peace_db';
$username = $env['MYSQL_USER'] ?? 'root';
$password = $env['MYSQL_PASSWORD'] ?? '';
$charset = 'utf8mb4';
$dsn = "mysql:host={$host};dbname={$database};charset={$charset}";

try {
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec("SET time_zone = '+00:00'");
} catch (PDOException $exception) {
    error_log('4Peace MySQL connection failed: ' . $exception->getMessage());
    http_response_code(500);
    exit('Database connection failed. Check the MySQL settings in Php_Version/.env.');
}
