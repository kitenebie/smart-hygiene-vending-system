# 4Peace PHP dashboard

MySQL/PHP counterpart of `react-app`. Import `database.sql` in MySQL or phpMyAdmin, then edit the ignored `.env` with your MySQL and Supabase settings. PHP PDO MySQL and cURL are required.

From the `react-app` directory, run `php -S localhost:8000 -t Php_Version` and open [http://localhost:8000/](http://localhost:8000/). Default seeded account: `admin` / `4peace2026`; change it after the first sign-in.

The dashboard reads display data from MySQL. On load, view changes, and every 30 seconds, `includes/supabase_sync.php` copies the Supabase dashboard tables into MySQL using upserts; append-only tables use an ID checkpoint. If Supabase is unavailable, the last MySQL backup is still displayed. Shared PHP actions write to Supabase first, then update MySQL, so the next backup sync keeps those changes.

The folder layout follows the existing `4peace-app` PHP project: `includes`, `assets`, `api`, and `config`.
