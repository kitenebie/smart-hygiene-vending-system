#pragma once 
#define WIFI_SSID "converge_5G"
#define WIFI_PASSWORD "67538298"
#define SUPABASE_URL "https://fjexweubnccjrinhxrct.supabase.co"
#define SUPABASE_KEY "sb_publishable_DRZfiimKuXLYdLvE-7iVxQ_yZLMr2OS"
#define DEVICE_API_KEY "4peace-esp32-live-token-2026"
