bool dispenseFailureMachineAlertPending = false;
bool dispenseFailureNotificationPending = false;
String deferredDispenseFailureMessage = "";
unsigned long lastDispenseFailureAlertAttempt = 0;

void deferDispenseFailureCloudAlert(const String &message)
{
  deferredDispenseFailureMessage = message;
  dispenseFailureMachineAlertPending = true;
  dispenseFailureNotificationPending = true;
  lastDispenseFailureAlertAttempt = 0;
}

void processDeferredDispenseFailureAlert()
{
  if (!dispenseFailureMachineAlertPending &&
      !dispenseFailureNotificationPending)
  {
    return;
  }

  if (currentState != STATE_IDLE || motorActive ||
      WiFi.status() != WL_CONNECTED)
  {
    return;
  }

  if (millis() - stateTimer < 3000UL)
    return;
  if (lastDispenseFailureAlertAttempt != 0 &&
      millis() - lastDispenseFailureAlertAttempt < 30000UL)
  {
    return;
  }
  lastDispenseFailureAlertAttempt = millis();

  if (dispenseFailureMachineAlertPending &&
      httpLogMachineAlert("critical", deferredDispenseFailureMessage))
  {
    dispenseFailureMachineAlertPending = false;
  }

  if (dispenseFailureNotificationPending &&
      httpPostNotification("system", "critical", deferredDispenseFailureMessage))
  {
    dispenseFailureNotificationPending = false;
  }

  if (!dispenseFailureMachineAlertPending &&
      !dispenseFailureNotificationPending)
  {
    deferredDispenseFailureMessage = "";
  }
}

void restoreStateAfterDispenseFailure(const String &method)
{
  selectedSlotIndex = -1;
  gcashRefBuffer = "";

  if (method == "coin" && currentCredit > 0.0f)
  {
    currentState = STATE_COIN_PAYMENT;

    paymentRetryPromptUntil = millis() + 1800UL;
  }
  else
  {
    currentState = STATE_IDLE;
    paymentRetryPromptUntil = 0;
  }

  stateTimer = millis();
}

bool sensorIsTriggeredStable(int pin, unsigned long stableMs)
{
  if (digitalRead(pin) != IR_TRIGGERED_LEVEL)
    return false;

  unsigned long started = millis();
  while (millis() - started < stableMs)
  {
    if (digitalRead(pin) != IR_TRIGGERED_LEVEL)
      return false;
    delay(2);
  }
  return true;
}

bool waitForNewIrDrop(int pin, unsigned long timeoutMs)
{
  unsigned long started = millis();

  while (millis() - started < timeoutMs)
  {
    if (sensorIsTriggeredStable(pin, SENSOR_STABLE_MS))
    {
      return true;
    }
    delay(5);
  }

  return false;
}

String makeTransactionId()
{
  char buffer[64];
  uint32_t rnd = esp_random();

  snprintf(
      buffer,
      sizeof(buffer),
      "%s-%08lX-%08lX",
      MACHINE_ID,
      (unsigned long)millis(),
      (unsigned long)rnd);

  return String(buffer);
}

String makeSmsEventId()
{
  char buffer[72];
  uint32_t rnd = esp_random();

  snprintf(
      buffer,
      sizeof(buffer),
      "%s-SMS-%08lX-%08lX",
      MACHINE_ID,
      (unsigned long)millis(),
      (unsigned long)rnd);

  return String(buffer);
}

int requiredSmsOutboxSlotsForVend(int slotIdx)
{
  if (slotIdx < 0 || slotIdx >= 5)
    return 2;

  return 2 + ((slots[slotIdx].stock - 1 <= lowStockThreshold) ? 1 : 0);
}

bool executeDispense(int slotIdx, const String &method, const String &refCode)
{
  if (slotIdx < 0 || slotIdx >= 5)
    return false;

  SlotItem &s = slots[slotIdx];
  Serial.printf("[VEND] Request: slot=%s method=%s stock=%d credit=P%.2f\n",
                s.slotCode.c_str(), method.c_str(), s.stock, currentCredit);
  logEsp32Event("dispense", "Request for " + s.slotCode + " - " + s.productName +
                                " via " + method + "; stock " + String(s.stock));

  if (s.stock <= 0)
  {
    updateLcd("OUT OF STOCK", s.slotCode);
    currentState = STATE_ERROR;
    delay(1000);
    currentState = STATE_IDLE;
    return false;
  }

  if (!pendingQueueHasSpace())
  {
    updateLcd("Sync Queue Full", "Service Locked");
    currentState = STATE_ERROR;
    beepBuzzer(4, 100);
    delay(1200);
    currentState = STATE_IDLE;
    return false;
  }

  if (!smsOutboxHasSpace(requiredSmsOutboxSlotsForVend(slotIdx)))
  {
    updateLcd("SMS Queue Full", "Service Locked");
    currentState = STATE_ERROR;
    beepBuzzer(4, 100);
    delay(1200);
    currentState = STATE_IDLE;
    return false;
  }

  if (sensorIsTriggeredStable(s.irPin, SENSOR_STABLE_MS))
  {
    Serial.printf("[IR] Slot %s sensor already blocked before vend.\n",
                  s.slotCode.c_str());
    logEsp32Event("ir_sensor", s.slotCode + " sensor blocked before dispense", "warning");
    deferDispenseFailureCloudAlert(
        "IR sensor blocked before vend on " + s.slotCode);
    restoreStateAfterDispenseFailure(method);
    updateLcd("IR Sensor Blocked",
              method == "coin" ? "Credit Retained" : s.slotCode);
    beepBuzzer(4, 100);
    return false;
  }

  PendingTx tx;
  tx.txId = makeTransactionId();
  tx.refCode = refCode;
  tx.method = method;
  tx.slotId = s.id;
  tx.amount = unitPrice;
  tx.completed = false;

  if (!enqueuePendingTransaction(tx))
  {
    Serial.println("[FATAL] Could not prepare the durable vend journal.");
    updateLcd("Journal Error", "Service Locked");
    currentState = STATE_ERROR;
    beepBuzzer(5, 120);
    delay(1200);
    currentState = STATE_IDLE;
    return false;
  }

  currentState = STATE_DISPENSING;
  updateLcd("Dispensing " + s.slotCode, s.productName);
  logEsp32Event("dispense", "Dispensing " + s.slotCode + " - " + s.productName);

  bool dropConfirmed = false;

  for (int attempt = 1; attempt <= DISPENSE_RETRY_COUNT; attempt++)
  {
    Serial.printf(
        "[DISPENSE] Slot %s attempt %d/%d, relay GPIO %d\n",
        s.slotCode.c_str(),
        attempt,
        DISPENSE_RETRY_COUNT,
        s.relayPin);

    motorActive = true;

    digitalWrite(s.relayPin, RELAY_ACTIVE_LEVEL);
    delay(10);
    int relayActiveLevel = digitalRead(s.relayPin);
    Serial.printf("[RELAY] %s GPIO%d command=%s readback=%s (%s)\n",
                  s.slotCode.c_str(), s.relayPin,
                  RELAY_ACTIVE_LEVEL == LOW ? "LOW/ON" : "HIGH/ON",
                  relayActiveLevel == LOW ? "LOW" : "HIGH",
                  relayActiveLevel == RELAY_ACTIVE_LEVEL ? "COMMAND OK" : "COMMAND MISMATCH");
    Serial.printf("[MOTOR] %s ON (GPIO%d)\n", s.slotCode.c_str(), s.relayPin);

    dropConfirmed = waitForNewIrDrop(s.irPin, DISPENSE_TIMEOUT_MS);

    digitalWrite(s.relayPin, RELAY_INACTIVE_LEVEL);
    delay(10);
    int relayInactiveLevel = digitalRead(s.relayPin);
    Serial.printf("[RELAY] %s GPIO%d command=%s readback=%s (%s)\n",
                  s.slotCode.c_str(), s.relayPin,
                  RELAY_INACTIVE_LEVEL == LOW ? "LOW/OFF" : "HIGH/OFF",
                  relayInactiveLevel == LOW ? "LOW" : "HIGH",
                  relayInactiveLevel == RELAY_INACTIVE_LEVEL ? "COMMAND OK" : "COMMAND MISMATCH");
    Serial.printf("[MOTOR] %s OFF | IR drop=%s\n", s.slotCode.c_str(),
                  dropConfirmed ? "CONFIRMED" : "NOT DETECTED");

    motorActive = false;

    logEsp32Event("relay", s.slotCode + " GPIO" + String(s.relayPin) + " ON command " + (relayActiveLevel == RELAY_ACTIVE_LEVEL ? "confirmed" : "mismatch"),
                  relayActiveLevel == RELAY_ACTIVE_LEVEL ? "info" : "error");
    logEsp32Event("relay", s.slotCode + " GPIO" + String(s.relayPin) + " OFF command " + (relayInactiveLevel == RELAY_INACTIVE_LEVEL ? "confirmed" : "mismatch"),
                  relayInactiveLevel == RELAY_INACTIVE_LEVEL ? "info" : "error");

    portENTER_CRITICAL(&tamperMux);
    tamperEdgeCount = 0;
    portEXIT_CRITICAL(&tamperMux);

    if (dropConfirmed)
    {
      logEsp32Event("ir_sensor", s.slotCode + " product-drop detected");
      break;
    }

    if (attempt < DISPENSE_RETRY_COUNT)
    {
      updateLcd("Retry Dispense", s.slotCode);
      delay(700);

      if (sensorIsTriggeredStable(s.irPin, SENSOR_STABLE_MS))
      {
        break;
      }
    }
  }

  if (!dropConfirmed)
  {
    Serial.printf("[VEND] FAILED: %s had no confirmed product drop; payment retained.\n",
                  s.slotCode.c_str());
    logEsp32Event("dispense", s.slotCode + " failed: no IR product-drop confirmation", "error");
    deferDispenseFailureCloudAlert(
        "Dispense failed on " + s.slotCode +
        ": IR did not confirm product drop");

    const bool journalCleared = removePendingTransaction(tx.txId);
    if (!journalCleared)
    {
      Serial.println("[FATAL] Could not clear unresolved prepared vend.");
      updateLcd("Journal Unclear", "Call Admin");
      selectedSlotIndex = -1;
      gcashRefBuffer = "";
      currentState = STATE_ERROR;
      beepBuzzer(5, 120);
      return false;
    }

    restoreStateAfterDispenseFailure(method);
    if (method == "coin" && currentCredit > 0.0f)
    {
      updateLcd("Dispense Failed",
                "Credit P" + String(currentCredit, 0) + " Retry");
    }
    else
    {
      updateLcd("Dispense Failed", "Payment Retained");
    }
    beepBuzzer(4, 120);
    return false;
  }

  currentState = STATE_SUCCESS;

  if (method == "coin")
  {
    currentCredit -= unitPrice;
    if (currentCredit < 0.0f)
      currentCredit = 0.0f;
    if (!persistCurrentCredit())
    {
      Serial.println("[FATAL] Remaining coin credit could not be saved to NVS.");
      updateLcd("Credit Save Err", "Service Locked");
      beepBuzzer(5, 120);
      selectedSlotIndex = -1;
      gcashRefBuffer = "";
      currentState = STATE_ERROR;
      return false;
    }
  }

  s.stock--;
  if (s.stock < 0)
    s.stock = 0;
  if (!persistStock(slotIdx))
  {
    Serial.println("[FATAL] Local stock could not be saved to NVS.");
    updateLcd("Stock Save Error", "Service Locked");
    beepBuzzer(5, 120);
    selectedSlotIndex = -1;
    gcashRefBuffer = "";
    currentState = STATE_ERROR;
    return false;
  }

  if (!markPendingTransactionCompleted(tx.txId))
  {
    Serial.println("[FATAL] Product dropped but journal completion failed.");
    updateLcd("Journal Unclear", "Call Admin");
    beepBuzzer(5, 120);
    selectedSlotIndex = -1;
    gcashRefBuffer = "";
    currentState = STATE_ERROR;
    return false;
  }
  Serial.printf("[VEND] SUCCESS: %s dispensed; local stock=%d; credit=P%.2f\n",
                s.slotCode.c_str(), s.stock, currentCredit);
  logEsp32Event("dispense", s.slotCode + " - " + s.productName +
                                " dispensed successfully; stock " + String(s.stock));

  String paymentMessage =
      "4Peace: Payment received P" + String(unitPrice, 2) +
      " via " + method + " for " + s.slotCode;
  String dispenseMessage =
      "4Peace: Dispensed " + s.productName +
      " (" + s.slotCode + "). Stock left: " + String(s.stock);

  queueSmsEvent("payment", paymentMessage);
  queueSmsEvent("dispensed_product", dispenseMessage);

  if (s.stock <= lowStockThreshold)
  {
    String msg =
        "Slot " + s.slotCode + " (" + s.productName + ") low stock: " +
        String(s.stock) + " left";

    queueSmsEvent("low_stock", "4Peace: " + msg);
  }

  Serial.printf("[VEND] Displaying success confirmation for %s (5 seconds).\n",
                s.productName.c_str());
  updateLcd(s.productName, "Dispensed");
  beepBuzzer(2, 90);
  delay(2500);
  updateLcd("Successfully!", "Please Take Item");
  delay(2500);

  selectedSlotIndex = -1;
  gcashRefBuffer = "";

  currentState = (currentCredit > 0.0f)
                     ? STATE_COIN_PAYMENT
                     : STATE_IDLE;

  stateTimer = millis();

  return true;
}
