#pragma once
#define WIFI_SSID "wifi"
#define WIFI_PASSWORD "3nt0923!!!"
#define SUPABASE_URL "https://fjexweubnccjrinhxrct.supabase.co"
#define SUPABASE_KEY "YOUR_SUPABASE_PUBLISHABLE_KEY"
#define DEVICE_API_KEY "YOUR_DEVICE_TOKEN"
