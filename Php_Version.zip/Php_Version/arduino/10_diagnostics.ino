float readRailVoltage(int adcPin, float dividerRatio)
{
#if ENABLE_VOLTAGE_MONITOR
  uint32_t millivolts = analogReadMilliVolts(adcPin);
  return (millivolts / 1000.0f) * dividerRatio;
#else
  (void)adcPin;
  (void)dividerRatio;
  return 0.0f;
#endif
}
