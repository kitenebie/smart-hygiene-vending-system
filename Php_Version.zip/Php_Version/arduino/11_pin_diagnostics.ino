enum PinCheckKind
{
  PIN_READ_ONLY,
  PIN_OUTPUT_PROBE,
  PIN_NO_TOUCH
};

struct PinProbe
{
  int gpio;
  const char *mode;
  PinCheckKind kind;
  int restoreLevel;
};

const PinProbe PIN_PROBES[] = {
    {0, "INPUT", PIN_READ_ONLY, LOW},
    {1, "UART0", PIN_NO_TOUCH, LOW},
    {2, "INPUT", PIN_READ_ONLY, LOW},
    {3, "UART0", PIN_NO_TOUCH, LOW},
    {4, "INPUT_PULLUP", PIN_READ_ONLY, LOW},
    {5, "INPUT", PIN_READ_ONLY, LOW},
    {6, "RESERVED (SPI flash)", PIN_NO_TOUCH, LOW},
    {7, "RESERVED (SPI flash)", PIN_NO_TOUCH, LOW},
    {8, "RESERVED (SPI flash)", PIN_NO_TOUCH, LOW},
    {9, "RESERVED (SPI flash)", PIN_NO_TOUCH, LOW},
    {10, "RESERVED (SPI flash)", PIN_NO_TOUCH, LOW},
    {11, "RESERVED (SPI flash)", PIN_NO_TOUCH, LOW},
    {12, "INPUT", PIN_READ_ONLY, LOW},
    {13, "OUTPUT / INPUT_PULLUP", PIN_OUTPUT_PROBE, RELAY_INACTIVE_LEVEL},
    {14, "OUTPUT / INPUT_PULLUP", PIN_OUTPUT_PROBE, RELAY_INACTIVE_LEVEL},
    {15, "INPUT", PIN_READ_ONLY, LOW},
    {16, "UART2", PIN_NO_TOUCH, LOW},
    {17, "UART2", PIN_NO_TOUCH, LOW},
    {18, "OUTPUT / INPUT_PULLUP", PIN_OUTPUT_PROBE, RELAY_INACTIVE_LEVEL},
    {19, "OUTPUT / INPUT_PULLUP", PIN_OUTPUT_PROBE, RELAY_INACTIVE_LEVEL},
    {21, "I2C", PIN_READ_ONLY, LOW},
    {22, "I2C", PIN_READ_ONLY, LOW},
    {23, "OUTPUT / INPUT_PULLUP", PIN_OUTPUT_PROBE, RELAY_INACTIVE_LEVEL},
    {25, "OUTPUT / INPUT_PULLUP", PIN_OUTPUT_PROBE, LOW},
    {26, "INPUT_PULLUP", PIN_READ_ONLY, LOW},
    {27, "INPUT", PIN_READ_ONLY, LOW},
    {32, "INPUT", PIN_READ_ONLY, LOW},
    {33, "INPUT", PIN_READ_ONLY, LOW},
    {34, "INPUT", PIN_READ_ONLY, LOW},
    {35, "INPUT", PIN_READ_ONLY, LOW},
    {36, "INPUT / ADC", PIN_READ_ONLY, LOW},
    {37, "INPUT", PIN_READ_ONLY, LOW},
    {38, "INPUT", PIN_READ_ONLY, LOW},
    {39, "INPUT / ADC", PIN_READ_ONLY, LOW}};

const size_t PIN_PROBE_COUNT = sizeof(PIN_PROBES) / sizeof(PIN_PROBES[0]);

const char *priorityPinLabel(int gpio)
{
  switch (gpio)
  {
  case TAMPER_SENSOR_PIN:
    return "Tamper Sensor";
  case RELAY_S1_PIN:
    return "S1 Relay";
  case RELAY_S2_PIN:
    return "S2 Relay";
  case RELAY_S3_PIN:
    return "S3 Relay";
  case RELAY_S4_PIN:
    return "S4 Relay";
  case RELAY_S5_PIN:
    return "S5 Relay";
  case I2C_SDA_PIN:
    return "I2C SDA (LCD)";
  case I2C_SCL_PIN:
    return "I2C SCL (LCD)";
  case BUZZER_PIN:
    return "Buzzer";
  case COIN_SIGNAL_PIN:
    return "Coin Acceptor";
  case IR_S5_PIN:
    return "S5 Sensor";
  case IR_S3_PIN:
    return "S3 Sensor";
  case IR_S4_PIN:
    return "S4 Sensor";
  case IR_S1_PIN:
    return "S1 Sensor";
  case IR_S2_PIN:
    return "S2 Sensor";
  case BUCK1_ADC_PIN:
    return "Buck 1 ADC";
  case BUCK2_ADC_PIN:
    return "Buck 2 ADC";
  case GSM_RX_PIN:
    return "SIM800L RX";
  case GSM_TX_PIN:
    return "SIM800L TX";
  default:
    return "";
  }
}

void restorePinDiagnosticOutputs()
{
  for (size_t i = 0; i < PIN_PROBE_COUNT; i++)
  {
    if (PIN_PROBES[i].kind != PIN_OUTPUT_PROBE)
      continue;

    digitalWrite(PIN_PROBES[i].gpio, PIN_PROBES[i].restoreLevel);
    pinMode(PIN_PROBES[i].gpio, OUTPUT);
  }
}

bool i2cDeviceResponds(uint8_t address)
{
  Wire.beginTransmission(address);
  return Wire.endTransmission() == 0;
}

bool httpSyncPinStatus(JsonArray pins)
{
  WiFiClientSecure client;
  configureSecureClient(client);
  HTTPClient http;
  String url = String(SUPABASE_URL) + "/rest/v1/rpc/sync_esp32_pin_status";

  if (!http.begin(client, url))
  {
    logSupabaseBeginFailure("POST", "rpc/sync_esp32_pin_status");
    return false;
  }
  addSupabaseHeaders(http, true);

  DynamicJsonDocument request(8192);
  request["p_device_key"] = DEVICE_API_KEY;
  request["p_machine_id"] = MACHINE_ID;
  JsonArray payloadPins = request.createNestedArray("p_pins");
  for (JsonObject pin : pins)
    payloadPins.add(pin);

  String body;
  serializeJson(request, body);
  logSupabaseRequest("POST", "rpc/sync_esp32_pin_status", body.length());
  int code = http.POST(body);
  String response = http.getString();
  logSupabaseResponse("POST", "rpc/sync_esp32_pin_status", code);
  http.end();

  StaticJsonDocument<256> ack;
  bool ok = code == 200 && !deserializeJson(ack, response) && (ack["success"] | false);
  Serial.printf("[PIN CHECK] HTTP %d, authenticated=%s\n", code, ok ? "yes" : "no");
  return ok;
}

void runPinConnectionDiagnostics()
{
  if (!pinConnectionDetectionEnabled || motorActive || currentState != STATE_IDLE)
    return;
  if (millis() - lastPinDiagnosticTime < PIN_DIAGNOSTIC_INTERVAL_MS)
    return;
  lastPinDiagnosticTime = millis();

  DynamicJsonDocument samples(8192);
  JsonArray pins = samples.to<JsonArray>();
  const bool i2cBusHealthy =
      i2cDeviceResponds(LCD_I2C_ADDR) && i2cDeviceResponds(PCF8574_I2C_ADDR);

  for (size_t i = 0; i < PIN_PROBE_COUNT; i++)
  {
    const PinProbe &probe = PIN_PROBES[i];
    const char *label = priorityPinLabel(probe.gpio);
    const bool assigned = label[0] != '\0';
    int value = HIGH;
    bool connected = false;
    String realtimeValue = "N/A";

    if (probe.gpio == I2C_SDA_PIN || probe.gpio == I2C_SCL_PIN)
    {
      connected = i2cBusHealthy;
      realtimeValue = i2cBusHealthy
                          ? "I2C devices acknowledged"
                          : "I2C device ACK missing";
    }
    else if (probe.kind == PIN_OUTPUT_PROBE)
    {

      value = digitalRead(probe.gpio);
      connected = assigned && value == probe.restoreLevel;
      realtimeValue = String(value == LOW ? "LOW" : "HIGH") +
                      " (safe output readback)";
    }
    else if (probe.kind == PIN_READ_ONLY)
    {
      value = digitalRead(probe.gpio);
      connected = assigned;
      realtimeValue = String(value == LOW ? "LOW" : "HIGH") +
                      " (non-invasive input sample)";
    }
    else if (assigned)
    {

      connected = true;
      realtimeValue = "Active peripheral; not electrically probed";
    }

    JsonObject pin = pins.createNestedObject();
    pin["gpio"] = probe.gpio;
    pin["pin_label"] = label;
    pin["current_mode"] = probe.mode;
    pin["connection_status"] = connected ? "connected" : "disconnected";
    pin["realtime_value"] = realtimeValue;
  }

  httpSyncPinStatus(pins);
}
