<?php
require_once __DIR__ . '/includes/auth_check.php';

$_SESSION = [];
session_destroy();

header('Location: login.php');
exit;
