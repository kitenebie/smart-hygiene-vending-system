-- ============================================================
-- 4Peace Admin Dashboard — Database Schema
-- IoT-Based Smart Feminine Hygiene Access System
-- Import this file in phpMyAdmin, or run:
--   mysql -u root -p < database.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS `4peace_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `4peace_db`;

-- ------------------------------------------------------------
-- Admins (dashboard login accounts)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) DEFAULT NULL,
  `phone` VARCHAR(20) DEFAULT NULL,
  `role` VARCHAR(30) DEFAULT 'Administrator',
  `last_login` DATETIME DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Default login: username = admin / password = 4peace2026
-- (hash generated with PHP password_hash — change this after first login!)
INSERT INTO `admins` (`username`, `password_hash`, `full_name`, `email`, `phone`, `role`)
VALUES (
  'admin',
  '$2y$10$BLT5MhHMT8SwwctDBvgf0.KmluQpSXfnu90CsrigECOATgCHbs28K',
  'Grace (Team 4Peace)',
  'team4peace@veritas.edu.ph',
  '+63 900 000 0000',
  'Administrator'
);

-- ------------------------------------------------------------
-- Slots (physical dispensing slots on the machine)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `slots` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `slot_code` VARCHAR(10) NOT NULL UNIQUE,   -- S1, S2, S3...
  `product_name` VARCHAR(100) NOT NULL,
  `stock` INT NOT NULL DEFAULT 0,
  `capacity` INT NOT NULL DEFAULT 30,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO `slots` (`slot_code`, `product_name`, `stock`, `capacity`) VALUES
('S1', 'Slot 1', 20, 30),
('S2', 'Slot 2', 20, 30),
('S3', 'Slot 3', 20, 30),
('S4', 'Slot 4', 20, 30),
('S5', 'Slot 5', 20, 30);

-- ------------------------------------------------------------
-- Transactions (every confirmed dispense)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ref_code` VARCHAR(30) NOT NULL,
  `method` ENUM('gcash','coin') NOT NULL,
  `slot_id` INT NOT NULL,
  `amount` DECIMAL(6,2) NOT NULL DEFAULT 10.00,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`slot_id`) REFERENCES `slots`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO `transactions` (`ref_code`, `method`, `slot_id`, `amount`, `created_at`) VALUES
('GC-88213',  'gcash', 1, 10.00, NOW() - INTERVAL 2 MINUTE),
('PLS-0417',  'coin',  4, 10.00, NOW() - INTERVAL 14 MINUTE),
('GC-88209',  'gcash', 5, 10.00, NOW() - INTERVAL 26 MINUTE),
('PLS-0416',  'coin',  2, 10.00, NOW() - INTERVAL 41 MINUTE),
('GC-88201',  'gcash', 3, 10.00, NOW() - INTERVAL 1 HOUR),
('PLS-0415',  'coin',  1, 10.00, NOW() - INTERVAL 1 HOUR);

-- ------------------------------------------------------------
-- Device health snapshot (latest sensor readings, one row kept updated)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `device_health` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `esp32_uptime_seconds` INT DEFAULT 0,
  `coin_pulses_session` INT DEFAULT 0,
  `sim800l_signal_pct` INT DEFAULT 0,
  `buck1_voltage` DECIMAL(4,2) DEFAULT 0.00,   -- 5V rail
  `buck2_voltage` DECIMAL(4,2) DEFAULT 0.00,   -- 4.2V rail for SIM800L
  `tamper_status` ENUM('idle','triggered') DEFAULT 'idle',
  `coin_box_pulses_total` INT DEFAULT 0,       -- running total for coin box level
  `coin_box_capacity_pulses` INT DEFAULT 1000, -- calibrate to physical box
  `last_sync` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO `device_health`
(`esp32_uptime_seconds`, `coin_pulses_session`, `sim800l_signal_pct`, `buck1_voltage`, `buck2_voltage`, `tamper_status`, `coin_box_pulses_total`, `coin_box_capacity_pulses`)
VALUES (570240, 41, 78, 5.02, 4.18, 'idle', 680, 1000);

-- ------------------------------------------------------------
-- Machine health logs (alert history)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `machine_health_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `level` ENUM('info','warning','critical') NOT NULL DEFAULT 'info',
  `message` VARCHAR(255) NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO `machine_health_logs` (`level`, `message`, `created_at`) VALUES
('warning',  'Slot S3 (Tampon — Regular) dropped below threshold (6 units left)', NOW() - INTERVAL 18 MINUTE),
('critical', 'Slot S5 (Sanitary Pad — Overnight) is now empty — SMS alert sent', NOW() - INTERVAL 52 MINUTE),
('info',     'Coin box level check — 68% capacity, within normal range', NOW() - INTERVAL 2 HOUR),
('info',     'Daily boot self-test passed — all sensors responding', NOW() - INTERVAL 6 HOUR);

-- ------------------------------------------------------------
-- Machine settings (single-row config used by dashboard + firmware)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `machine_settings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `unit_price` DECIMAL(6,2) NOT NULL DEFAULT 10.00,
  `low_stock_threshold` INT NOT NULL DEFAULT 5,
  `coin_box_alert_pct` INT NOT NULL DEFAULT 80,
  `admin_sms_number` VARCHAR(20) DEFAULT NULL,
  `tamper_alarm_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `auto_reset_coin_count` TINYINT(1) NOT NULL DEFAULT 0,
  `enable_pin_connection_detection` TINYINT(1) NOT NULL DEFAULT 0,
  `device_api_key` VARCHAR(64) DEFAULT NULL,   -- shared secret the ESP32 sends on gcash_verify.php / gcash_status.php
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO `machine_settings`
(`unit_price`, `low_stock_threshold`, `coin_box_alert_pct`, `admin_sms_number`, `tamper_alarm_enabled`, `auto_reset_coin_count`, `device_api_key`)
VALUES (10.00, 5, 80, '+63 900 000 0000', 1, 0, '4peace-dev-key-2026');

-- ------------------------------------------------------------
-- GCash payments (reference number entered on keypad, waiting
-- for admin to confirm it matches an incoming SMS from GCash)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `gcash_payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ref_code` VARCHAR(30) NOT NULL,
  `amount` DECIMAL(6,2) NOT NULL DEFAULT 10.00,
  `slot_id` INT DEFAULT NULL,
  `status` ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `consumed_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `resolved_at` DATETIME DEFAULT NULL,
  FOREIGN KEY (`slot_id`) REFERENCES `slots`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO `gcash_payments` (`ref_code`, `amount`, `slot_id`, `status`, `created_at`, `resolved_at`) VALUES
('GC-99231', 10.00, 3, 'pending',  NOW() - INTERVAL 3 MINUTE, NULL),
('GC-88213', 10.00, 1, 'approved', NOW() - INTERVAL 40 MINUTE, NOW() - INTERVAL 38 MINUTE),
('GC-88190', 10.00, 5, 'rejected', NOW() - INTERVAL 2 HOUR, NOW() - INTERVAL 2 HOUR);

-- ------------------------------------------------------------
-- Notifications (unified feed — stock, coin box, tamper, gcash, sms)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `type` ENUM('gcash','stock','coin_box','tamper','system','sms') NOT NULL DEFAULT 'system',
  `level` ENUM('info','warning','critical') NOT NULL DEFAULT 'info',
  `message` VARCHAR(255) NOT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO `notifications` (`type`, `level`, `message`, `is_read`, `created_at`) VALUES
('gcash',    'info',     'New GCash reference GC-99231 submitted — awaiting your approval', 0, NOW() - INTERVAL 3 MINUTE),
('stock',    'warning',  'Slot S3 (Tampon — Regular) dropped below threshold (6 units left)', 0, NOW() - INTERVAL 18 MINUTE),
('gcash',    'info',     'GCash reference GC-88213 approved — dispense allowed', 1, NOW() - INTERVAL 38 MINUTE),
('stock',    'critical', 'Slot S5 (Sanitary Pad — Overnight) is now empty — SMS alert sent', 1, NOW() - INTERVAL 52 MINUTE),
('gcash',    'warning',  'GCash reference GC-88190 rejected — no matching SMS found', 1, NOW() - INTERVAL 2 HOUR),
('coin_box', 'info',     'Coin box level check — 68% capacity, within normal range', 1, NOW() - INTERVAL 2 HOUR),
('system',   'info',     'Daily boot self-test passed — all sensors responding', 1, NOW() - INTERVAL 6 HOUR);

-- ------------------------------------------------------------
-- SMS outbox and ESP32 event history (dashboard log screens)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `sms` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `client_event_id` VARCHAR(100) NOT NULL UNIQUE,
  `machine_id` VARCHAR(32) NOT NULL,
  `event_type` ENUM('dispensed_product','payment','theft_alert','low_stock') NOT NULL,
  `recipient` VARCHAR(30) NOT NULL,
  `message` VARCHAR(320) NOT NULL,
  `status` ENUM('pending','sent') NOT NULL DEFAULT 'pending',
  `attempt_count` INT NOT NULL DEFAULT 0,
  `last_attempt_at` DATETIME DEFAULT NULL,
  `last_error` VARCHAR(255) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sent_at` DATETIME DEFAULT NULL,
  INDEX `sms_created_idx` (`created_at`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `esp32_logs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `machine_id` VARCHAR(32) NOT NULL,
  `level` ENUM('info','warning','error') NOT NULL DEFAULT 'info',
  `category` VARCHAR(64) NOT NULL,
  `message` VARCHAR(500) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `esp32_logs_machine_created_idx` (`machine_id`,`created_at`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `device_resource_logs` (
  `id` BIGINT PRIMARY KEY,
  `machine_id` VARCHAR(32) NOT NULL,
  `internal_sram_total_bytes` BIGINT NOT NULL,
  `internal_sram_free_bytes` BIGINT NOT NULL,
  `external_psram_total_bytes` BIGINT NOT NULL,
  `external_psram_free_bytes` BIGINT NOT NULL,
  `external_flash_total_bytes` BIGINT NOT NULL,
  `external_flash_used_bytes` BIGINT NOT NULL,
  `filesystem_total_bytes` BIGINT NOT NULL,
  `filesystem_used_bytes` BIGINT NOT NULL,
  `rom_total_bytes` BIGINT NOT NULL,
  `cpu_temperature_c` DECIMAL(5,2) DEFAULT NULL,
  `collected_at` DATETIME NOT NULL,
  INDEX `device_resource_logs_collected_idx` (`collected_at`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `esp32_pin_status` (
  `id` BIGINT PRIMARY KEY,
  `machine_id` VARCHAR(32) NOT NULL,
  `gpio` SMALLINT NOT NULL,
  `pin_label` VARCHAR(100) NOT NULL DEFAULT '',
  `current_mode` VARCHAR(100) NOT NULL,
  `connection_status` VARCHAR(20) NOT NULL,
  `realtime_value` VARCHAR(100) NOT NULL,
  `updated_at` DATETIME NOT NULL,
  UNIQUE KEY `esp32_pin_status_gpio` (`machine_id`,`gpio`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `esp32_pin_devices` (
  `id` BIGINT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `image_url` TEXT NOT NULL,
  `created_at` DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `esp32_pin_device_assignments` (
  `machine_id` VARCHAR(32) NOT NULL,
  `gpio` SMALLINT NOT NULL,
  `device_id` BIGINT NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`machine_id`,`gpio`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `supabase_sync_state` (
  `table_name` VARCHAR(64) PRIMARY KEY,
  `last_id` BIGINT NOT NULL DEFAULT 0
) ENGINE=InnoDB;
