<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/supabase_sync.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? [];
$id     = (int)($data['id'] ?? 0);
$action = $data['action'] ?? '';

if (!$id || !in_array($action, ['approve', 'reject'], true)) {
    http_response_code(400);
    echo json_encode(['error' => 'id and a valid action (approve/reject) are required']);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM gcash_payments WHERE id = ?");
$stmt->execute([$id]);
$payment = $stmt->fetch();

if (!$payment) {
    http_response_code(404);
    echo json_encode(['error' => 'Payment not found']);
    exit;
}
if ($payment['status'] !== 'pending') {
    http_response_code(409);
    echo json_encode(['error' => 'This reference was already ' . $payment['status']]);
    exit;
}

$status = $action === 'approve' ? 'approved' : 'rejected';
$resolvedAt = gmdate('Y-m-d\TH:i:s\Z');
try {
    $resolved = write_supabase_rows('gcash_payments', [
        'id' => 'eq.' . $id,
        'status' => 'eq.pending',
        'consumed_at' => 'is.null',
    ], 'PATCH', ['status' => $status, 'resolved_at' => $resolvedAt]);
    if (!$resolved) {
        http_response_code(409);
        echo json_encode(['error' => 'This reference was already resolved.']);
        exit;
    }
} catch (Throwable $exception) {
    error_log('Supabase GCash update failed: ' . $exception->getMessage());
    http_response_code(502);
    echo json_encode(['error' => 'Could not update the payment in Supabase.']);
    exit;
}

$level = $action === 'approve' ? 'info' : 'warning';
$message = $action === 'approve'
    ? "GCash reference {$payment['ref_code']} approved — dispense allowed"
    : "GCash reference {$payment['ref_code']} rejected — no matching SMS found";
try {
    write_supabase_rows('notifications', [], 'POST', ['type' => 'gcash', 'level' => $level, 'message' => $message]);
} catch (Throwable $exception) {
    error_log('Supabase GCash notification insert failed: ' . $exception->getMessage());
}

$pdo->beginTransaction();
try {
    $pdo->prepare('UPDATE gcash_payments SET status = ?, resolved_at = UTC_TIMESTAMP() WHERE id = ?')->execute([$status, $id]);
    add_notification($pdo, 'gcash', $level, $message);
    $pdo->commit();
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('MySQL GCash mirror update failed: ' . $exception->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Payment was updated in Supabase, but MySQL could not be updated. It will sync again shortly.']);
    exit;
}

echo json_encode(['success' => true, 'status' => $action === 'approve' ? 'approved' : 'rejected']);
