<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');

// All statuses, newest first, capped — pending ones matter most but admin
// should also see recently resolved ones for context.
$rows = $pdo->query("SELECT g.*, s.slot_code, s.product_name FROM gcash_payments g
    LEFT JOIN slots s ON s.id = g.slot_id
    ORDER BY g.created_at DESC")->fetchAll();

$out = array_map(function ($g) {
    return [
        'id'           => (int)$g['id'],
        'ref_code'     => $g['ref_code'],
        'amount'       => (float)$g['amount'],
        'slot_code'    => $g['slot_code'] ?? '—',
        'product_name' => $g['product_name'] ?? '—',
        'status'       => $g['status'],
        'consumed_at'  => $g['consumed_at'],
        'time'         => time_ago($g['created_at']),
    ];
}, $rows);

echo json_encode($out);
