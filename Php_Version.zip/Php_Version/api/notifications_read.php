<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/supabase_sync.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

try {
    write_supabase_rows('notifications', ['is_read' => 'eq.false'], 'PATCH', ['is_read' => true]);
} catch (Throwable $exception) {
    error_log('Supabase notification update failed: ' . $exception->getMessage());
    http_response_code(502);
    echo json_encode(['error' => 'Could not update notifications in Supabase.']);
    exit;
}
$pdo->exec("UPDATE notifications SET is_read = 1 WHERE is_read = 0");

echo json_encode(['success' => true]);
