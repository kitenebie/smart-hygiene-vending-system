<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');

$settings = get_setting($pdo);
$lowThreshold = (int)($settings['low_stock_threshold'] ?? 5);

$slots = $pdo->query("SELECT * FROM slots ORDER BY slot_code")->fetchAll();

$out = array_map(function ($s) use ($lowThreshold) {
    return [
        'id'           => (int)$s['id'],
        'slot_code'    => $s['slot_code'],
        'product_name' => $s['product_name'],
        'stock'        => (int)$s['stock'],
        'capacity'     => (int)$s['capacity'],
        'status'       => slot_status((int)$s['stock'], $lowThreshold),
    ];
}, $slots);

echo json_encode($out);
