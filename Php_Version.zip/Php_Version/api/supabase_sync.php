<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/supabase_sync.php';

try {
    echo json_encode(['success' => true, 'synced' => sync_supabase_to_mysql($pdo)], JSON_THROW_ON_ERROR);
} catch (Throwable $exception) {
    error_log('Supabase to MySQL sync failed: ' . $exception->getMessage());
    http_response_code(502);
    echo json_encode(['error' => 'Supabase sync failed. Check credentials, connectivity, and that the Supabase migrations are applied.']);
}
