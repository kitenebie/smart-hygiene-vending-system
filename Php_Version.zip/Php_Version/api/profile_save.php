<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$fullName = trim($data['full_name'] ?? '');
$username = trim($data['username'] ?? '');
$email    = trim($data['email'] ?? '');
$phone    = trim($data['phone'] ?? '');
$password = $data['password'] ?? '';

if ($fullName === '' || $username === '') {
    http_response_code(422);
    echo json_encode(['error' => 'Full name and username are required.']);
    exit;
}

// username uniqueness check (excluding self)
$check = $pdo->prepare("SELECT id FROM admins WHERE username = ? AND id != ?");
$check->execute([$username, $_SESSION['admin_id']]);
if ($check->fetch()) {
    http_response_code(422);
    echo json_encode(['error' => 'That username is already taken.']);
    exit;
}

if ($password !== '') {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE admins SET full_name=?, username=?, email=?, phone=?, password_hash=? WHERE id=?");
    $stmt->execute([$fullName, $username, $email, $phone, $hash, $_SESSION['admin_id']]);
} else {
    $stmt = $pdo->prepare("UPDATE admins SET full_name=?, username=?, email=?, phone=? WHERE id=?");
    $stmt->execute([$fullName, $username, $email, $phone, $_SESSION['admin_id']]);
}

$_SESSION['admin_name'] = $fullName;

echo json_encode(['success' => true]);
