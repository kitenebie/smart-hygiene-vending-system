<?php
/**
 * DEVICE-FACING ENDPOINT — called by the ESP32 firmware, not the browser.
 * No PHP session here; protected instead by machine_settings.device_api_key.
 *
 * Flow: user selects a slot on the keypad, chooses GCash, types the GCash
 * reference number. ESP32 POSTs it here. We save it as "pending" and the
 * admin later approves/rejects it from the dashboard (Transactions tab).
 * The ESP32 should then poll api/gcash_status.php with the same ref_code.
 *
 * Request (POST, JSON body):
 *   { "device_key": "...", "ref_code": "GC-12345", "slot_id": 3, "amount": 10 }
 *
 * Response:
 *   { "success": true, "payment_id": 7, "status": "pending" }
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? [];
require_device_key($pdo, $data['device_key'] ?? null);

$refCode = trim($data['ref_code'] ?? '');
$slotId  = isset($data['slot_id']) ? (int)$data['slot_id'] : null;

if ($refCode === '') {
    http_response_code(400);
    echo json_encode(['error' => 'ref_code is required']);
    exit;
}

$settings = get_setting($pdo);
$amount = isset($data['amount']) ? (float)$data['amount'] : (float)$settings['unit_price'];

// Avoid duplicate pending entries for the same ref_code
$existing = $pdo->prepare("SELECT id, status FROM gcash_payments WHERE ref_code = ? ORDER BY id DESC LIMIT 1");
$existing->execute([$refCode]);
$row = $existing->fetch();
if ($row && $row['status'] === 'pending') {
    echo json_encode(['success' => true, 'payment_id' => (int)$row['id'], 'status' => 'pending', 'note' => 'already pending']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO gcash_payments (ref_code, amount, slot_id, status) VALUES (?, ?, ?, 'pending')");
$stmt->execute([$refCode, $amount, $slotId]);
$paymentId = (int)$pdo->lastInsertId();

add_notification($pdo, 'gcash', 'info', "New GCash reference {$refCode} submitted — awaiting your approval");

echo json_encode(['success' => true, 'payment_id' => $paymentId, 'status' => 'pending']);
