<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');

$limit = isset($_GET['limit']) ? max(1, min(100, (int)$_GET['limit'])) : 25;

$stmt = $pdo->prepare("SELECT t.*, s.slot_code FROM transactions t
    LEFT JOIN slots s ON s.id = t.slot_id
    ORDER BY t.created_at DESC LIMIT :lim");
$stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
$stmt->execute();
$rows = $stmt->fetchAll();

$out = array_map(function ($t) {
    return [
        'ref_code' => $t['ref_code'],
        'method'   => $t['method'],
        'slot'     => $t['slot_code'] ?? '—',
        'amount'   => (float)$t['amount'],
        'time'     => time_ago($t['created_at']),
    ];
}, $rows);

echo json_encode($out);
