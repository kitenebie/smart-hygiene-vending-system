<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');

$h = $pdo->query("SELECT * FROM device_health ORDER BY id DESC LIMIT 1")->fetch();
$logs = $pdo->query("SELECT * FROM machine_health_logs ORDER BY created_at DESC LIMIT 10")->fetchAll();
$hasResourceTable = $pdo->query("SHOW TABLES LIKE 'device_resource_logs'")->fetchColumn();
$resources = $hasResourceTable ? $pdo->query("SELECT * FROM device_resource_logs ORDER BY collected_at DESC LIMIT 360")->fetchAll() : [];

$metrics = [];
if ($h) {
    $metrics[] = ['name' => 'ESP32 Uptime', 'value' => format_uptime((int)$h['esp32_uptime_seconds']), 'pct' => 92, 'status' => 'ok'];
    $metrics[] = ['name' => 'Coin pulses (session)', 'value' => (string)$h['coin_pulses_session'], 'pct' => min(100, (int)$h['coin_pulses_session']), 'status' => 'accent'];
    $metrics[] = ['name' => 'SIM800L Signal', 'value' => $h['sim800l_signal_pct'] >= 50 ? 'Good' : 'Weak', 'pct' => (int)$h['sim800l_signal_pct'], 'status' => $h['sim800l_signal_pct'] >= 50 ? 'ok' : 'warn'];
    $metrics[] = ['name' => '5V Rail (Buck #1)', 'value' => number_format($h['buck1_voltage'], 2) . 'V', 'pct' => 96, 'status' => 'ok'];
    $metrics[] = ['name' => '4.2V Rail (Buck #2)', 'value' => number_format($h['buck2_voltage'], 2) . 'V', 'pct' => 88, 'status' => 'ok'];
    $metrics[] = ['name' => 'Tamper sensor', 'value' => $h['tamper_status'] === 'idle' ? 'Idle' : 'TRIGGERED', 'pct' => $h['tamper_status'] === 'idle' ? 100 : 100, 'status' => $h['tamper_status'] === 'idle' ? 'ok' : 'crit'];
}

$logsOut = array_map(function ($l) {
    return ['level' => $l['level'], 'text' => $l['message'], 'time' => time_ago($l['created_at'])];
}, $logs);

echo json_encode(['metrics' => $metrics, 'logs' => $logsOut, 'resources' => $resources]);
