<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/supabase_sync.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}
$data = json_decode(file_get_contents('php://input'), true) ?? [];
$gpio = filter_var($data['gpio'] ?? null, FILTER_VALIDATE_INT);
$deviceId = filter_var($data['device_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$allowedPins = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,21,22,23,25,26,27,32,33,34,35,36,37,38,39];
if ($gpio === false || !in_array($gpio, $allowedPins, true) || !$deviceId) {
    http_response_code(400);
    echo json_encode(['error' => 'Choose a valid PIN and device.']);
    exit;
}
$exists = $pdo->prepare('SELECT id FROM esp32_pin_devices WHERE id = ?');
$exists->execute([$deviceId]);
if (!$exists->fetchColumn()) {
    http_response_code(404);
    echo json_encode(['error' => 'Device not found.']);
    exit;
}
try {
    $result = call_supabase_rpc('assign_esp32_pin_device', ['p_machine_id' => 'VM001', 'p_gpio' => $gpio, 'p_device_id' => $deviceId]);
    if (empty($result['success'])) throw new RuntimeException($result['message'] ?? 'Unable to save the device assignment.');
    $save = $pdo->prepare('INSERT INTO esp32_pin_device_assignments (machine_id,gpio,device_id,updated_at) VALUES (?,?,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE device_id=VALUES(device_id),updated_at=VALUES(updated_at)');
    $save->execute(['VM001', $gpio, $deviceId]);
    echo json_encode(['success' => true]);
} catch (Throwable $exception) {
    error_log('ESP32 PIN assignment failed: ' . $exception->getMessage());
    http_response_code(502);
    echo json_encode(['error' => $exception->getMessage()]);
}
