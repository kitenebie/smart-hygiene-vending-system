<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
header('Content-Type: application/json; charset=utf-8');

$stmt = $pdo->query('SELECT id,machine_id,event_type,recipient,message,status,attempt_count,last_attempt_at,last_error,created_at,sent_at FROM sms ORDER BY created_at DESC LIMIT 100');
echo json_encode($stmt->fetchAll(), JSON_THROW_ON_ERROR);
