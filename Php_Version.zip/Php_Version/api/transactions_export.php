<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';

$rows = $pdo->query("SELECT t.ref_code, t.method, s.slot_code, s.product_name, t.amount, t.created_at
    FROM transactions t JOIN slots s ON s.id = t.slot_id
    ORDER BY t.created_at DESC")->fetchAll();

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="4peace-transactions-' . date('Y-m-d') . '.csv"');

$out = fopen('php://output', 'w');
fputcsv($out, ['Reference', 'Method', 'Slot', 'Product', 'Amount', 'Date/Time']);
foreach ($rows as $r) {
    fputcsv($out, [$r['ref_code'], $r['method'], $r['slot_code'], $r['product_name'], $r['amount'], $r['created_at']]);
}
fclose($out);
