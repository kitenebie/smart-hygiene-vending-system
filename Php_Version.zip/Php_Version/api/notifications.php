<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');

$rows = $pdo->query("SELECT * FROM notifications ORDER BY created_at DESC")->fetchAll();

$out = array_map(function ($n) {
    return [
        'id'      => (int)$n['id'],
        'type'    => $n['type'],
        'level'   => $n['level'],
        'message' => $n['message'],
        'is_read' => (bool)$n['is_read'],
        'time'    => time_ago($n['created_at']),
    ];
}, $rows);

$unread = $pdo->query("SELECT COUNT(*) c FROM notifications WHERE is_read = 0")->fetch()['c'];

echo json_encode(['notifications' => $out, 'unread_count' => (int)$unread]);
