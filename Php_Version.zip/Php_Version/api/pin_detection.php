<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/supabase_sync.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}
$data = json_decode(file_get_contents('php://input'), true) ?? [];
if (!is_bool($data['enabled'] ?? null)) {
    http_response_code(400);
    echo json_encode(['error' => 'A boolean enabled value is required.']);
    exit;
}
$row = $pdo->query('SELECT id FROM machine_settings ORDER BY id DESC LIMIT 1')->fetch();
if (!$row) {
    http_response_code(404);
    echo json_encode(['error' => 'Machine settings not found.']);
    exit;
}
try {
    write_supabase_rows('machine_settings', ['id' => 'eq.' . $row['id']], 'PATCH', ['enable_pin_connection_detection' => $data['enabled']]);
    $stmt = $pdo->prepare('UPDATE machine_settings SET enable_pin_connection_detection = ? WHERE id = ?');
    $stmt->execute([(int)$data['enabled'], (int)$row['id']]);
    echo json_encode(['success' => true]);
} catch (Throwable $exception) {
    error_log('ESP32 PIN detection update failed: ' . $exception->getMessage());
    http_response_code(502);
    echo json_encode(['error' => 'Could not update ESP32 PIN connection detection.']);
}
