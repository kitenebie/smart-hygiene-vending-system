<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/supabase_sync.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? [];
$id          = (int)($data['id'] ?? 0);
$productName = trim($data['product_name'] ?? '');
$capacity    = isset($data['capacity']) ? (int)$data['capacity'] : null;

if (!$id || $productName === '') {
    http_response_code(400);
    echo json_encode(['error' => 'id and product_name are required']);
    exit;
}

try {
    $payload = ['product_name' => $productName];
    if ($capacity !== null && $capacity > 0) $payload['capacity'] = $capacity;
    write_supabase_rows('slots', ['id' => 'eq.' . $id], 'PATCH', $payload);
} catch (Throwable $exception) {
    error_log('Supabase slot update failed: ' . $exception->getMessage());
    http_response_code(502);
    echo json_encode(['error' => 'Could not save the slot to Supabase.']);
    exit;
}

if ($capacity !== null && $capacity > 0) {
    $stmt = $pdo->prepare("UPDATE slots SET product_name = ?, capacity = ? WHERE id = ?");
    $stmt->execute([$productName, $capacity, $id]);
} else {
    $stmt = $pdo->prepare("UPDATE slots SET product_name = ? WHERE id = ?");
    $stmt->execute([$productName, $id]);
}

echo json_encode(['success' => true]);
