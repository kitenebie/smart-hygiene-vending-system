<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
header('Content-Type: application/json; charset=utf-8');

$hasPinTable = $pdo->query("SHOW TABLES LIKE 'esp32_pin_status'")->fetchColumn();
$pins = $hasPinTable ? $pdo->query("SELECT s.gpio,s.pin_label,s.current_mode,s.connection_status,s.realtime_value,s.updated_at,d.id AS device_id,d.name AS device_name,d.image_url
    FROM esp32_pin_status s
    LEFT JOIN esp32_pin_device_assignments a ON a.machine_id = s.machine_id AND a.gpio = s.gpio
    LEFT JOIN esp32_pin_devices d ON d.id = a.device_id
    WHERE s.machine_id = 'VM001' ORDER BY s.gpio")->fetchAll() : [];
$devices = $hasPinTable ? $pdo->query('SELECT id,name,image_url FROM esp32_pin_devices ORDER BY name')->fetchAll() : [];
echo json_encode(['pins' => $pins, 'devices' => $devices], JSON_THROW_ON_ERROR);
