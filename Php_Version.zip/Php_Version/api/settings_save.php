<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/supabase_sync.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$unitPrice   = (float)($data['unit_price'] ?? 10);
$lowStock    = (int)($data['low_stock_threshold'] ?? 5);
$coinAlert   = (int)($data['coin_box_alert_pct'] ?? 80);
$smsNumber   = trim($data['admin_sms_number'] ?? '');
$tamperOn    = !empty($data['tamper_alarm_enabled']) ? 1 : 0;
$autoReset   = !empty($data['auto_reset_coin_count']) ? 1 : 0;
$pinDetection = !empty($data['enable_pin_connection_detection']) ? 1 : 0;
$deviceKey   = trim($data['device_api_key'] ?? '');

$row = $pdo->query("SELECT id, device_api_key FROM machine_settings ORDER BY id DESC LIMIT 1")->fetch();
// Never let the key be blanked out accidentally — keep the old one if the field was left empty.
if ($deviceKey === '' && $row) {
    $deviceKey = $row['device_api_key'];
}

$settings = [
    'unit_price' => $unitPrice,
    'low_stock_threshold' => $lowStock,
    'coin_box_alert_pct' => $coinAlert,
    'admin_sms_number' => $smsNumber,
    'tamper_alarm_enabled' => (bool)$tamperOn,
    'auto_reset_coin_count' => (bool)$autoReset,
    'enable_pin_connection_detection' => (bool)$pinDetection,
    'device_api_key' => $deviceKey,
];
try {
    if ($row) write_supabase_rows('machine_settings', ['id' => 'eq.' . $row['id']], 'PATCH', $settings);
    else write_supabase_rows('machine_settings', [], 'POST', $settings);
} catch (Throwable $exception) {
    error_log('Supabase settings update failed: ' . $exception->getMessage());
    http_response_code(502);
    echo json_encode(['error' => 'Could not save settings to Supabase.']);
    exit;
}

if ($row) {
    $stmt = $pdo->prepare("UPDATE machine_settings SET
        unit_price = ?, low_stock_threshold = ?, coin_box_alert_pct = ?,
        admin_sms_number = ?, tamper_alarm_enabled = ?, auto_reset_coin_count = ?, enable_pin_connection_detection = ?, device_api_key = ?
        WHERE id = ?");
    $stmt->execute([$unitPrice, $lowStock, $coinAlert, $smsNumber, $tamperOn, $autoReset, $pinDetection, $deviceKey, $row['id']]);
} else {
    $stmt = $pdo->prepare("INSERT INTO machine_settings
        (unit_price, low_stock_threshold, coin_box_alert_pct, admin_sms_number, tamper_alarm_enabled, auto_reset_coin_count, enable_pin_connection_detection, device_api_key)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$unitPrice, $lowStock, $coinAlert, $smsNumber, $tamperOn, $autoReset, $pinDetection, $deviceKey]);
}

echo json_encode(['success' => true]);
