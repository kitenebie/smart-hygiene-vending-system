<?php
/**
 * DEVICE-FACING ENDPOINT — called by the ESP32 firmware to poll whether the
 * admin has approved a GCash reference number yet. Poll every few seconds
 * after gcash_verify.php while the LCD shows "waiting for confirmation".
 *
 * Request (GET):
 *   api/gcash_status.php?ref_code=GC-12345&device_key=...
 *
 * Response:
 *   { "status": "pending" | "approved" | "rejected" | "not_found" }
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');

require_device_key($pdo, $_GET['device_key'] ?? null);

$refCode = trim($_GET['ref_code'] ?? '');
if ($refCode === '') {
    http_response_code(400);
    echo json_encode(['error' => 'ref_code is required']);
    exit;
}

$stmt = $pdo->prepare("SELECT status FROM gcash_payments WHERE ref_code = ? ORDER BY id DESC LIMIT 1");
$stmt->execute([$refCode]);
$row = $stmt->fetch();

echo json_encode(['status' => $row ? $row['status'] : 'not_found']);
