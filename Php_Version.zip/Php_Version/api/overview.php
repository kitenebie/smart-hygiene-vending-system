<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');

$settings = get_setting($pdo);
$lowThreshold = (int)($settings['low_stock_threshold'] ?? 5);

// stock totals
$slots = $pdo->query("SELECT * FROM slots ORDER BY slot_code")->fetchAll();
$totalStock = 0; $totalCap = 0; $lowStockSlots = [];
$slotDispenses = [];
$productLabels = []; $productStocks = [];
foreach ($slots as $s) {
    $totalStock += (int)$s['stock'];
    $totalCap += (int)$s['capacity'];
    $status = slot_status((int)$s['stock'], $lowThreshold);
    if ($status !== 'ok') {
        $lowStockSlots[] = ['slot_code' => $s['slot_code'], 'product_name' => $s['product_name'], 'stock' => (int)$s['stock'], 'status' => $status];
    }
    $productLabels[] = $s['slot_code'] . ': ' . trim(explode('—', $s['product_name'])[0]);
    $productStocks[] = (int)$s['stock'];
}

$transactions = $pdo->query("SELECT slot_id, amount, method, created_at FROM transactions ORDER BY created_at ASC")->fetchAll();
$trendByDate = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $label = $i === 0 ? 'Today' : ($i === 1 ? 'Yesterday' : date('M j', strtotime($date)));
    $trendByDate[$date] = ['label' => $label, 'sales' => 0, 'gcash' => 0, 'coin' => 0];
}
$paymentAmounts = ['gcash' => 0, 'coin' => 0];
foreach ($transactions as $transaction) {
    $date = substr($transaction['created_at'], 0, 10);
    if (!isset($trendByDate[$date])) {
        $trendByDate[$date] = ['label' => date('M j', strtotime($date)), 'sales' => 0, 'gcash' => 0, 'coin' => 0];
    }
    $method = $transaction['method'] === 'gcash' ? 'gcash' : 'coin';
    $trendByDate[$date]['sales'] += (float)$transaction['amount'];
    $trendByDate[$date][$method]++;
    $paymentAmounts[$method] += (float)$transaction['amount'];
    if ($transaction['slot_id'] !== null) {
        $slotId = (int)$transaction['slot_id'];
        $slotDispenses[$slotId] = ($slotDispenses[$slotId] ?? 0) + 1;
    }
}
ksort($trendByDate);
$trendByDate = array_slice($trendByDate, -7, null, true);
$productDispenses = [];
$stockLabels = [];
foreach ($slots as $s) {
    $productDispenses[] = $slotDispenses[(int)$s['id']] ?? 0;
    $stockLabels[] = $s['slot_code'] . ' (' . mb_substr($s['product_name'], 0, 14) . '…)';
}
$paymentCounts = [0, 0];
foreach ($transactions as $transaction) {
    $paymentCounts[$transaction['method'] === 'gcash' ? 0 : 1]++;
}
if ($paymentCounts[0] === 0) $paymentCounts[0] = 1;
if ($paymentCounts[1] === 0) $paymentCounts[1] = 1;

// today's sales + dispense count
$today = $pdo->prepare("SELECT COUNT(*) as cnt, COALESCE(SUM(amount),0) as total,
    SUM(CASE WHEN method='gcash' THEN 1 ELSE 0 END) as gcash_cnt,
    SUM(CASE WHEN method='coin' THEN 1 ELSE 0 END) as coin_cnt
    FROM transactions WHERE DATE(created_at) = CURDATE()");
$today->execute();
$todayRow = $today->fetch();

// yesterday's sales (for delta)
$yest = $pdo->prepare("SELECT COALESCE(SUM(amount),0) as total FROM transactions WHERE DATE(created_at) = CURDATE() - INTERVAL 1 DAY");
$yest->execute();
$yestTotal = (float)$yest->fetch()['total'];
$todayTotal = (float)$todayRow['total'];
$salesDelta = $yestTotal > 0 ? round((($todayTotal - $yestTotal) / $yestTotal) * 100) : null;

// coin box level
$health = $pdo->query("SELECT * FROM device_health ORDER BY id DESC LIMIT 1")->fetch();
$pinSync = $pdo->query("SHOW TABLES LIKE 'esp32_pin_status'")->fetchColumn()
    ? $pdo->query("SELECT MAX(updated_at) FROM esp32_pin_status WHERE machine_id = 'VM001'")->fetchColumn()
    : null;
$lastSync = max(array_filter([$health['last_sync'] ?? null, $pinSync]) ?: [null]);
$coinBoxPct = 0;
if ($health && (int)$health['coin_box_capacity_pulses'] > 0) {
    $coinBoxPct = round(((int)$health['coin_box_pulses_total'] / (int)$health['coin_box_capacity_pulses']) * 100);
}

// recent activity: merge transactions + logs, most recent first
$recentTx = $pdo->query("SELECT t.*, s.slot_code, s.product_name FROM transactions t
    LEFT JOIN slots s ON s.id = t.slot_id ORDER BY t.created_at DESC LIMIT 5")->fetchAll();
$recentLogs = $pdo->query("SELECT * FROM machine_health_logs ORDER BY created_at DESC LIMIT 5")->fetchAll();

$activity = [];
foreach ($recentTx as $t) {
    $activity[] = [
        'type' => 'tx',
        'text' => ($t['method'] === 'gcash' ? 'GCash' : 'Coin') . " payment of ₱" . number_format($t['amount'], 2) . ' — ' . ($t['slot_code'] ?? '') . ' (' . ($t['product_name'] ?? '') . ')',
        'time' => $t['created_at'],
        'time_label' => time_ago($t['created_at']),
        'level' => 'info',
    ];
}
foreach ($recentLogs as $l) {
    $activity[] = [
        'type' => 'log',
        'text' => $l['message'],
        'time' => $l['created_at'],
        'time_label' => time_ago($l['created_at']),
        'level' => $l['level'],
    ];
}
usort($activity, fn($a, $b) => strtotime($b['time']) <=> strtotime($a['time']));
$activity = array_slice($activity, 0, 6);

echo json_encode([
    'units_left'      => $totalStock,
    'units_capacity'  => $totalCap,
    'today_sales'     => $todayTotal,
    'sales_delta_pct' => $salesDelta,
    'dispenses_today' => (int)$todayRow['cnt'],
    'gcash_count'     => (int)$todayRow['gcash_cnt'],
    'coin_count'      => (int)$todayRow['coin_cnt'],
    'coin_box_pct'    => $coinBoxPct,
    'low_stock_slots' => $lowStockSlots,
    'activity'        => $activity,
    'last_sync'       => $lastSync,
    'trend_dates'     => array_column($trendByDate, 'label'),
    'trend_sales'     => array_column($trendByDate, 'sales'),
    'trend_gcash'     => array_column($trendByDate, 'gcash'),
    'trend_coin'      => array_column($trendByDate, 'coin'),
    'product_labels'  => $productLabels,
    'product_dispenses' => $productDispenses,
    'product_stocks'  => $productStocks,
    'payment_counts'  => $paymentCounts,
    'payment_amounts' => [$paymentAmounts['gcash'], $paymentAmounts['coin']],
    'stock_labels'    => $stockLabels,
    'stock_values'    => $productStocks,
]);
