<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/supabase_sync.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true) ?? [];
$slotId = filter_var($data['slot_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$quantity = filter_var($data['quantity'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if (!$slotId || !$quantity) {
    http_response_code(400);
    echo json_encode(['error' => 'Enter a valid slot and stock quantity.']);
    exit;
}

$stmt = $pdo->prepare('SELECT slot_code, stock, capacity FROM slots WHERE id = ?');
$stmt->execute([$slotId]);
$slot = $stmt->fetch();
if (!$slot) {
    http_response_code(404);
    echo json_encode(['error' => 'Slot not found.']);
    exit;
}
if ($quantity > (int)$slot['capacity'] - (int)$slot['stock']) {
    http_response_code(400);
    echo json_encode(['error' => 'Only ' . max(0, (int)$slot['capacity'] - (int)$slot['stock']) . ' item(s) fit in ' . $slot['slot_code'] . '.']);
    exit;
}

try {
    $result = call_supabase_rpc('restock_slot', ['p_slot_id' => $slotId, 'p_quantity' => $quantity]);
    if (empty($result['success'])) {
        http_response_code(409);
        echo json_encode(['error' => $result['message'] ?? 'Restock was rejected.']);
        exit;
    }
    $stmt = $pdo->prepare('UPDATE slots SET stock = ?, capacity = ?, updated_at = UTC_TIMESTAMP() WHERE id = ?');
    $stmt->execute([(int)$result['stock'], (int)$result['capacity'], $slotId]);
    echo json_encode($result);
} catch (Throwable $exception) {
    error_log('Slot restock failed: ' . $exception->getMessage());
    http_response_code(502);
    echo json_encode(['error' => 'Could not add stock. Please refresh the slots and try again.']);
}
