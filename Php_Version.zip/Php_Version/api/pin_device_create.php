<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/supabase_sync.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}
$data = json_decode(file_get_contents('php://input'), true) ?? [];
$name = trim((string)($data['name'] ?? ''));
$imageUrl = trim((string)($data['image_url'] ?? ''));
$scheme = parse_url($imageUrl, PHP_URL_SCHEME);
if (mb_strlen($name) < 1 || mb_strlen($name) > 100 || ($imageUrl !== '' && (!filter_var($imageUrl, FILTER_VALIDATE_URL) || !in_array(strtolower((string)$scheme), ['http', 'https'], true)))) {
    http_response_code(400);
    echo json_encode(['error' => 'Enter a device name up to 100 characters and a valid image link.']);
    exit;
}
try {
    $device = call_supabase_rpc('create_esp32_pin_device', ['p_name' => $name, 'p_image_url' => $imageUrl]);
    if (isset($device[0]) && is_array($device[0])) $device = $device[0];
    $save = $pdo->prepare('INSERT INTO esp32_pin_devices (id,name,image_url,created_at) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),image_url=VALUES(image_url)');
    $save->execute([(int)$device['id'], $device['name'], $device['image_url'] ?? '', gmdate('Y-m-d H:i:s')]);
    echo json_encode(['id' => (int)$device['id'], 'name' => $device['name'], 'image_url' => $device['image_url'] ?? '']);
} catch (Throwable $exception) {
    error_log('ESP32 PIN device creation failed: ' . $exception->getMessage());
    http_response_code(502);
    echo json_encode(['error' => $exception->getMessage()]);
}
