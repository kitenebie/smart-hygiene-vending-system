<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_login();
require_once __DIR__ . '/../config/db.php';
header('Content-Type: application/json; charset=utf-8');

$stmt = $pdo->prepare('SELECT id,machine_id,level,category,message,created_at FROM esp32_logs WHERE machine_id = ? ORDER BY created_at DESC LIMIT 250');
$stmt->execute(['VM001']);
echo json_encode($stmt->fetchAll(), JSON_THROW_ON_ERROR);
