<?php
/**
 * Include this at the top of every protected page / API endpoint.
 * Redirects to login.php (or returns 401 for API calls) if not logged in.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function is_logged_in(): bool {
    return isset($_SESSION['admin_id']);
}

function require_login(): void {
    if (!is_logged_in()) {
        // If this looks like an API/AJAX request, return JSON 401 instead of redirecting
        $isApi = str_contains($_SERVER['REQUEST_URI'] ?? '', '/api/')
              || (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest');

        if ($isApi) {
            http_response_code(401);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Not authenticated']);
            exit;
        }

        header('Location: login.php');
        exit;
    }
}
