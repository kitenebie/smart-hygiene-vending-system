<?php
require_once __DIR__ . '/includes/auth_check.php';
require_once __DIR__ . '/config/db.php';

// Already logged in? go straight to dashboard
if (is_logged_in()) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Please enter both username and password.';
    } else {
        $stmt = $pdo->prepare('SELECT * FROM admins WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password_hash'])) {
            $_SESSION['admin_id']   = $admin['id'];
            $_SESSION['admin_name'] = $admin['full_name'];

            $upd = $pdo->prepare('UPDATE admins SET last_login = NOW() WHERE id = ?');
            $upd->execute([$admin['id']]);

            header('Location: index.php');
            exit;
        } else {
            $error = 'Invalid username or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Log in — 4Peace Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Work+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-body">

  <div class="login-wrap">
    <div class="login-card">
      <div class="login-brand">
        <div class="brand-glyph">4P</div>
        <div>
          <div class="brand-name display">4Peace</div>
          <div class="brand-sub">MACHINE ADMIN</div>
        </div>
      </div>

      <h1 class="login-title display">Welcome back</h1>
      <p class="login-sub">Log in to manage slots, transactions, and machine settings.</p>

      <?php if ($error): ?>
        <div class="login-error"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="POST" class="login-form">
        <label class="field-label" for="username">Username</label>
        <input type="text" id="username" name="username" class="input" placeholder="admin" autocomplete="username" required autofocus>

        <label class="field-label" for="password" style="margin-top:14px;">Password</label>
        <input type="password" id="password" name="password" class="input" placeholder="••••••••" autocomplete="current-password" required>

        <button type="submit" class="btn login-submit">Log in</button>
      </form>

      <div class="login-foot">Team 4Peace · Veritas College of Irosin</div>
    </div>
  </div>

</body>
</html>
